# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Depot::Application.config.secret_token = '8ede9b10231279b7471858c94eb2e7ff45e4df72813455032c042a8738e188ad73e91c61eca88e17dbe8a3c393e4955f45c8a7c75529de272ea284b12051476e'
